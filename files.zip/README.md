# MAHAGENCO Integrated Analytics Platform

## 📊 Master Dashboard Implementation

Complete analytics suite for Maharashtra State Power Generation Company (MAHAGENCO) with real-time monitoring, forecasting, and financial reporting.

---

## 📦 Files Overview

### 1. **MAHAGENCO-Master-Dashboard.jsx** (31 KB, 629 lines)
**Complete integrated dashboard** combining all 6 dashboards in a single file.

**Features:**
- 6 Main Dashboards
- Real-time KPI metrics
- Interactive charts and tables
- Comprehensive data integration

**Included Dashboards:**
1. **Generation Dashboard** - Total generation, source breakdown, 24-hour trends
2. **Power Plant Dashboard** - Unit performance, financial impact analysis
3. **Outage Dashboard** - Outage tracking, capacity distribution, thermal outages
4. **Cost Recovery Dashboard** - Financial metrics, fuel cost breakdown, recovery rates
5. **MOD & Prediction Dashboard** - Merit Order Dispatch, coal GCV, 7-day forecasts
6. **Profitability Dashboard** - Income/expenditure analysis, unit profitability, P&L trends

---

## 🚀 Individual Dashboard Files

If you need individual dashboards:

- **power-plant-dashboards.jsx** (24 KB) - Centralized power plant monitoring
- **mahagenco-dashboard.jsx** (23 KB) - Generation status tracking
- **mahagenco-outage-dashboard.jsx** (20 KB) - Outage management
- **mahagenco-cost-recovery-dashboard.jsx** (33 KB) - Cost recovery analysis
- **daily-mod-dashboard.jsx** (25 KB) - MOD & future predictions
- **daily-profitability-dashboard.jsx** (22 KB) - Daily profitability report

---

## 📈 Key Metrics Tracked

### Generation
- Total Fleet Generation: 19,400 MW
- Capacity: 23,000 MW
- Utilization: 84.3%
- Renewable Share: 23.8%

### Outage Management
- Total Outage Capacity: 5,450 MW
- Ongoing Outages: 3
- Forced Outages: 2

### Financial
- Total Income: ₹1,323 Cr
- Total Expenditure: ₹1,625 Cr
- Net Loss: -₹302 Cr
- Coal Cost: 52.3% of expenditure

### Cost Recovery
- Total Generation Cost: ₹12,500 Cr
- Recovery Rate: 87.0%
- Disallowance: 13.0%

### MOD & Prediction
- Daily Generation: 3,850 MW
- Coal GCV Avg: 4,158 cal/g
- Coal Stock: 14.0 days
- Critical Alerts: 2

---

## 🎯 Dashboard Features

### Interactive Navigation
- **Tab-based interface** for switching between dashboards
- **Sub-tabs** within each dashboard for detailed analysis
- **Real-time KPI cards** with key metrics
- **Multiple chart types**: Pie, Bar, Line, Area charts

### Data Visualization
- **Pie charts** for composition analysis
- **Bar charts** for performance comparison
- **Line charts** for trend analysis
- **Area charts** for stacked trends
- **Tables** for detailed data viewing

### Business Logic
- **Auto-calculated metrics** (utilization, margins, recovery rates)
- **Conditional formatting** for status indicators
- **Color-coded alerts** (Red=Critical, Orange=High, Yellow=Medium)
- **30-day historical trends**

---

## 🔧 Technical Stack

- **Framework**: React.js
- **Charts**: Recharts
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Responsive**: Mobile-first design

---

## 📊 Data Sources

- **SAP**: Power sales, cost data, coal consumption
- **CWS**: Transmission loss, revenue burn, dispatch data
- **SCADA**: Real-time generation, unit parameters
- **Coal Mines**: GCV data, rake tracking, quality metrics
- **Internal Systems**: Outage schedules, maintenance plans

---

## 💡 Usage

### Installation
```bash
npm install react recharts lucide-react
```

### Implementation
```jsx
import MAHAGENCOMasterDashboard from './MAHAGENCO-Master-Dashboard';

function App() {
  return <MAHAGENCOMasterDashboard />;
}
```

### Live Data Integration
Replace sample data with live API calls:
```jsx
const [generationData, setGenerationData] = useState([]);

useEffect(() => {
  fetch('/api/generation')
    .then(res => res.json())
    .then(data => setGenerationData(data));
}, []);
```

---

## 🎨 Dashboard Themes

- **Generation**: Blue gradient
- **Power Plant**: Blue & Green gradient
- **Outage**: Red gradient
- **Cost Recovery**: Green gradient
- **MOD**: Purple gradient
- **Profitability**: Amber gradient

---

## 📱 Responsive Design

- ✅ Desktop (1920px+)
- ✅ Laptop (1440px)
- ✅ Tablet (768px)
- ✅ Mobile (360px+)

---

## 🔐 Security Considerations

- Remove hardcoded data in production
- Implement authentication/authorization
- Use secure API endpoints
- Validate all incoming data
- Encrypt sensitive information

---

## 📞 Support

For questions or issues:
- MAHAGENCO Operations: operations@mahagenco.in
- Finance: finance@mahagenco.in
- MERC Compliance: merc@mahagenco.in

---

## 📄 License

MAHAGENCO Internal Use Only
© Maharashtra State Power Generation Company Limited

---

**Last Updated**: 27-Feb-2026
**Version**: 1.0
**Status**: Production Ready
